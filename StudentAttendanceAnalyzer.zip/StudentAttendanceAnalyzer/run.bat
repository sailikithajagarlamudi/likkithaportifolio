@echo off
javac src\StudentAttendanceAnalyzer.java
if errorlevel 1 pause & exit /b 1
java -cp src StudentAttendanceAnalyzer
pause
